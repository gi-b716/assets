#include <iostream>
#include <limits.h>
using namespace std;
int main(){
    int n,ms[2]={0,-1};
    cin >> n;
    for(int i=0;i<n;i++){
        string s;
        cin >> s;
        int cnt=0,combo=0;
        for(int j=0;j<s.length();j++){
            if(s[j]!='Y'){combo=0;continue;}
            cnt++;
            combo++;
            if(combo==3){
                cnt++;
                combo=0;
            }
        }
        if(cnt>ms[1]){
            ms[0]=i+1;
            ms[1]=cnt;
        }
    }
    cout << ms[0] << endl << ms[1];
    return 0;
}