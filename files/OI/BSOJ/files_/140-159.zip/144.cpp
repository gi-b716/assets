#include <iostream>
using namespace std;

int lcm(int a, int b) {
  if(a<b){
  	int temp=a;
  	a = b;b = temp;
  }
  int ans=a;
  for(;1;){
  	if(ans%a==0 && ans%b==0){
  		break;
	}
	ans++;
  }
  return ans;
}

int main(){
	int x,y;
	cin >> x >> y;
	cout << lcm(x,y);
	return 0;
}
