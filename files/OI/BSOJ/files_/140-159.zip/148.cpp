#include<iostream>

using namespace std;
int main()
{
  int n,g,s,c,tg,ts,tc,tot;
  tg = 0;
  ts = 0;
  tc = 0;
  cin >> n;
  for(int i = 1;i <= n;i ++)
  {
  	cin >> g >> s >> c;
    tg += g;
    ts += s;
    tc += c;
    tot = tg + ts + tc;
  }
  cout << tg << " " << ts  << " " << tc  << " " << tot;
  return 0;
}
