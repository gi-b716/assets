#include <iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	for(int i=1;i<=n;i++){
		if(i==10000) continue;
		int a = i/1000;
		int b = (i%1000)/100;
		int c = (i%100)/10;
		int d = i%10;
		if(a*a*a+b*b*b+c*c*c+d*d*d==i) cout << i << endl;
	}
	return 0;
}
