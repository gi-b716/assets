#include <iostream>
using namespace std;

long long jc(int n){
	long long s=1;
	for(int i=1;i<=n;i++) s*=i;
	return s;
}

int main(){
	int n;
	cin >> n;
	long long ans=0;
	for(int c=1;c<=n;c++) ans+=jc(c);
	cout << ans;
	return 0;
}
