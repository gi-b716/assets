#include <iostream>
using namespace std;
int main(){
	double x,y,z;
	cin >> x >> y >> z;
	for(int i=1;i<=100;i++){
		for(int j=1;j<=100;j++){
			for(int k=1;k<=100;k++){
				if(i*x+j*y+k*z==100 && i+j+k==100) cout << i << " " << j << " " << k << endl;
			}
		} 
	} 
	return 0;
}
