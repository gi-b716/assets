#include <iostream>
using namespace std;
int main(){
	 double s=0;
	 int m,i=1;
	 cin >> m;
	 while(s<=m){
	 	s += 1.0/i;
	 	i++;
	 }
	 cout << i-2;
	 return 0;
}
