#include <iostream>
using namespace std;
int main(){
	int n,top;
	cin >> n;
	top = 1+(n-1)*2;
	int tt=top;
	for(int i=0;i<n;i++){
		for(int j=0;j<top-tt;j++) cout << " ";
		for(int j=0;j<tt;j++) cout << "*";
		cout << endl;
		tt -= 2;
	}
	return 0;
}
