/*
#include <iostream>
using namespace std;
int main(){
	int n;
	cin >> n;
	for(int i=0;i<n;i++){
		for(int space=0;space<(n-i-1);space++) cout<<" ";
		int j,temp=65,l=i+1;
		for(j=0;j<l;j++){
			cout << (char)temp;
			temp++;
		}
		for(;j>0;j--){
			cout << (char)temp;
			temp--;	
		}
	} 
	return 0;
}*/

#include<iostream>
using namespace std;
int main()
{
    int n;
    cin >> n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n-i;j++) cout << " ";
        for(int j=1;j<=i;j++) cout << char(64+j);
        for(int j=i-1;j>=1;j--) cout << char(64+j);
        cout << endl;
    }
    return 0;
}
 
