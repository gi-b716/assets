#include <iostream>
#include <iomanip>
using namespace std;
int main(){
	int x,n;
	cin >> x >> n;
	double p=x;
	for(int i=0;i<n;i++){
		p *= 1.001;
	}
	cout << fixed << setprecision(4) << p;
	return 0;
}
